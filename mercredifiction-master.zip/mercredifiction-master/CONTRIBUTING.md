# Contributing

Please report issues on <https://framagit.org/luc/last/issues>

If you made a theme and want it to be available in official repository, merge requests are welcome!

For hacking, do:

```
git clone https://framagit.org/luc/last.git
cd last
sudo apt-get install libxml2-dev
sudo cpan Carton
carton install
carton exec ./build.pl
```
